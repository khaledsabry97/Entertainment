<?php

require('connection.php');



$query = $_POST["query"];


$sql = $query;

if ($conn->query($sql) === TRUE) {
    $last_id = $conn->insert_id;
	mysqli_close($conn);

	if (strpos($query, '`user`') !== false) {
		require('connection.php');
    $sql = "insert into `category`(`name`,`user_id`,`type`) values('favourite',$last_id,2)";
	$conn->query($sql);
	mysqli_close($conn);
	require('connection.php');
	$sql = "insert into `category`(`name`,`user_id`,`type`) values('history',$last_id,1)";
	$conn->query($sql);
	mysqli_close($conn);


}
	echo json_encode(array("server_response"=>True));

	}
else
	echo json_encode(array("server_response"=>False));
	
	
mysqli_close($conn);


?>
