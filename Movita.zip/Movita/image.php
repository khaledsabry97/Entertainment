<?php

require('connection.php');



$user_id = $_POST["user_id"];
$image_name = $_POST["image_name"];
$image_base64 = $_POST["image_base64"];
$path = 'images/'. $user_id . "-" . $image_name . '.png';
if (file_put_contents($path, base64_decode($image_base64)) ==TRUE)
{
$path = "http://movita97.000webhostapp.com/Movita/" . $path;
$sql = "insert into `image`(`user_id`,`name`,`path`) values($user_id,'$image_name','$path') ON DUPLICATE KEY UPDATE path = '$path'";

if ($conn->query($sql) === TRUE) {
	echo json_encode(array("server_response"=>True));
	}
else
		echo json_encode(array("server_response"=>False));
}
else
			echo json_encode(array("server_response"=>False));
			

mysqli_close($conn);

	
	


?>
