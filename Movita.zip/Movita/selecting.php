<?php
require('connection.php');


if (isset($_POST['query']))
{
	$query = $_POST["query"];


$sql = $query;

$result = mysqli_query($conn ,$sql);


$arrays = array();
	while ($row = mysqli_fetch_assoc($result)) {
		
		$arrays[] = $row;

	}

	echo json_encode(array("server_response"=>$arrays));


    mysqli_free_result($result);
	}
mysqli_close($conn);

?>
