<?php


$conn = mysqli_connect("localhost","id11554828_khaled","khaled","id11554828_movita");

if(!$conn)
{
	echo json_encode(array("server_response"=>"server down"));
	exit();
	
}


?>
