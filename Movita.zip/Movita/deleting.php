<?php

require('connection.php');



$query = $_POST["query"];


$sql = $query;

if ($conn->query($sql) === TRUE) {
	mysqli_close($conn);
	echo json_encode(array("server_response"=>True));
}
else
	echo json_encode(array("server_response"=>False));
	
	
	


?>
